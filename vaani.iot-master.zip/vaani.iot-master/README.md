# Project Vaani (No Longer Under Active Development)
  
**Vaani.IoT** is at an early stage of development. Thus, despite our deep desire for external contributions, we are not quite ready to receive them yet.

However, when that moment arrives, and we are ready for external contributions, we will announce it far and wide, adding blog posts and instructions on getting started with **Vaani.IoT**.

<p align="center">
  
  <img src="https://raw.githubusercontent.com/mozilla/vaani.iot/master/images/Vaani.IoT.jpg" alt="Vaani.IoT"/>
</p>
